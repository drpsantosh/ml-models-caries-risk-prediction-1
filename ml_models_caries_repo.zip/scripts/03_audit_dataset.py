import pandas as pd
from src.config import Config
from src.data import load_dataset

cfg = Config()
df = load_dataset(cfg.data_csv)

print("Rows:", len(df))
print("Event rate:", df[cfg.y_col].mean())
print("Missing values:")
print(df.isna().sum())
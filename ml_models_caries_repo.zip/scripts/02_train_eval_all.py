from src.config import Config
from src.data import load_dataset
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report

cfg = Config()
df = load_dataset(cfg.data_csv)

X = df.drop(columns=[cfg.y_col])
y = df[cfg.y_col]

X_train, X_test, y_train, y_test = train_test_split(X,y,test_size=0.2,random_state=42,stratify=y)

model = LogisticRegression(max_iter=1000)
model.fit(X_train.select_dtypes(include="number"), y_train)

pred = model.predict(X_test.select_dtypes(include="number"))
print(classification_report(y_test, pred))
from pathlib import Path
from src.make_synthetic_data import make_synthetic_caries_dataset

out = Path("data/synthetic")
out.mkdir(parents=True, exist_ok=True)

df = make_synthetic_caries_dataset()
df.to_csv(out/"caries_synth.csv", index=False)
print("Synthetic dataset created:", df.shape)
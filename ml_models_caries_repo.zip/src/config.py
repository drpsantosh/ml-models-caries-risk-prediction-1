from dataclasses import dataclass

@dataclass(frozen=True)
class Config:
    seed: int = 42
    test_size: float = 0.20
    cv_folds: int = 5
    data_csv: str = "data/synthetic/caries_synth.csv"
    y_col: str = "outcome_caries_12m"
    id_col: str = "id"
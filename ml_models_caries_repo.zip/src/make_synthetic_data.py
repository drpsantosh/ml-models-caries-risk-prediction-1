import numpy as np
import pandas as pd

def make_synthetic_caries_dataset(n: int = 318, seed: int = 42) -> pd.DataFrame:
    rng = np.random.default_rng(seed)
    df = pd.DataFrame({
        "id": np.arange(1, n+1),
        "age_years": rng.integers(6, 13, size=n),
        "sex": rng.choice(["Male","Female"], size=n),
        "past_caries_dmft": rng.normal(1.6, 0.7, size=n),
        "salivary_ph": rng.normal(6.1, 0.25, size=n),
        "sugar_exposures_per_day": rng.normal(2.5, 0.9, size=n),
        "fluoridated_toothpaste": rng.choice(["Yes","No"], size=n),
        "brushing_ge_2day": rng.choice(["Yes","No"], size=n),
        "parent_education_ge_hs": rng.choice(["Yes","No"], size=n),
        "plaque_index": rng.normal(1.2, 0.4, size=n),
        "dental_care_access": rng.choice(["Yes","No"], size=n),
        "snacking_between_meals": rng.choice(["Yes","No"], size=n),
        "brushing_supervised": rng.choice(["Yes","No"], size=n),
    })
    logit = (
        0.9 * df["past_caries_dmft"]
        + 0.6 * df["sugar_exposures_per_day"]
        - 1.2 * (df["salivary_ph"] - 6.0)
    )
    prob = 1/(1+np.exp(-(logit-2.5)))
    df["outcome_caries_12m"] = (rng.random(n) < prob).astype(int)
    return df
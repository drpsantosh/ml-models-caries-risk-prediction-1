# Data

This repository includes a **synthetic dataset** for demonstration.
The real participant-level dataset cannot be shared due to ethics restrictions.
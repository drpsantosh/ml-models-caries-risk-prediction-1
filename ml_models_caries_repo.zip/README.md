# ML models for pediatric caries risk prediction (reproducible pipeline)

This repository contains an executable end-to-end machine-learning pipeline for:
- preprocessing (encoding, scaling, imputation),
- stratified 5-fold cross-validation,
- nested feature selection (RFE) inside CV,
- hyperparameter tuning,
- threshold optimization using Youden’s J statistic,
- independent test-set evaluation,
- ROC and calibration plots.

## Quickstart

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python scripts/01_make_synth_data.py
python scripts/02_train_eval_all.py
python scripts/03_audit_dataset.py
```

The repository includes a **synthetic dataset** for demonstration. The real study dataset cannot be publicly shared due to ethics restrictions.
# Caries editor package

Included files:
- code/ml_models_pipeline_manuscript_consistent.py
  Full manuscript-consistent ML pipeline for Logistic Regression, Random Forest, and XGBoost.
- code/recompute_from_predictions.py
  Verification script that recomputes metrics from the supplied test prediction file.
- data/exact_test_predictions.csv
  Test-set prediction file for direct recomputation of confusion-matrix-based metrics.
- data/reconstructed_caries_dataset.csv
  Reconstructed/synthetic dataset for workflow transparency.
- data/data_dictionary.csv
  Data dictionary.

Important:
- The reconstructed dataset is not the original patient-level dataset.
- The prediction file is intended for exact recomputation of reported confusion-matrix-based metrics.

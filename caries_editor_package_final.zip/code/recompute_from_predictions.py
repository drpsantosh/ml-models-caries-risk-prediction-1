from pathlib import Path
import pandas as pd
import numpy as np
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, roc_auc_score, confusion_matrix, matthews_corrcoef, brier_score_loss

BASE = Path(__file__).resolve().parents[1]
PRED_FILE = BASE / "data" / "exact_test_predictions.csv"
OUT_DIR = BASE / "reports"
THRESHOLD = 0.50

def metrics_from_probs(y_true, prob, threshold=0.50):
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    return {
        "TP": int(tp),
        "FP": int(fp),
        "TN": int(tn),
        "FN": int(fn),
        "Accuracy": accuracy_score(y_true, pred),
        "Precision": precision_score(y_true, pred, zero_division=0),
        "Recall": recall_score(y_true, pred, zero_division=0),
        "F1": f1_score(y_true, pred, zero_division=0),
        "MCC": matthews_corrcoef(y_true, pred),
        "AUC": roc_auc_score(y_true, prob),
        "Brier": brier_score_loss(y_true, prob)
    }

def net_benefit(y_true, prob, pt):
    pred = (prob >= pt).astype(int)
    tp = ((pred == 1) & (y_true == 1)).sum()
    fp = ((pred == 1) & (y_true == 0)).sum()
    n = len(y_true)
    return (tp / n) - (fp / n) * (pt / (1 - pt))

def treat_all_net_benefit(y_true, pt):
    y_true = np.asarray(y_true)
    n = len(y_true)
    tp = (y_true == 1).sum()
    fp = (y_true == 0).sum()
    return (tp / n) - (fp / n) * (pt / (1 - pt))

def main():
    OUT_DIR.mkdir(exist_ok=True)
    df = pd.read_csv(PRED_FILE)
    y_true = df["y_true"].values

    metrics_rows = []
    dca_rows = []

    for label, col in [("Logistic Regression", "lr_prob"), ("Random Forest", "rf_prob"), ("XGBoost", "xgb_prob")]:
        prob = df[col].values
        m = metrics_from_probs(y_true, prob, THRESHOLD)
        metrics_rows.append({"Model": label, **m})
        for pt in [0.10, 0.20, 0.30]:
            dca_rows.append({
                "Model": label,
                "Threshold": pt,
                "NetBenefit": net_benefit(y_true, prob, pt),
                "TreatAll": treat_all_net_benefit(y_true, pt),
                "TreatNone": 0.0
            })

    metrics_df = pd.DataFrame(metrics_rows)
    dca_df = pd.DataFrame(dca_rows)
    metrics_df.to_csv(OUT_DIR / "recomputed_metrics_from_predictions.csv", index=False)
    dca_df.to_csv(OUT_DIR / "decision_curve_net_benefit.csv", index=False)

    with open(OUT_DIR / "summary_from_predictions.txt", "w", encoding="utf-8") as f:
        f.write("Metrics recomputed from exact_test_predictions.csv using threshold 0.50\n\n")
        f.write(metrics_df.to_string(index=False))
        f.write("\n\n")
        f.write(dca_df.to_string(index=False))

    print(metrics_df.to_string(index=False))
    print()
    print(dca_df.to_string(index=False))

if __name__ == "__main__":
    main()

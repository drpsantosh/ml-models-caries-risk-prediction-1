
from __future__ import annotations

from pathlib import Path
import json
import warnings

import numpy as np
import pandas as pd

from sklearn.base import clone
from sklearn.compose import ColumnTransformer
from sklearn.feature_selection import RFE
from sklearn.impute import KNNImputer, SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    confusion_matrix,
    matthews_corrcoef,
    brier_score_loss,
)
from sklearn.model_selection import StratifiedKFold, train_test_split, GridSearchCV
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.ensemble import RandomForestClassifier

try:
    from xgboost import XGBClassifier
except Exception as e:
    raise ImportError("xgboost is required for this script. Install xgboost>=1.7") from e

warnings.filterwarnings("ignore")

RANDOM_STATE = 42
TEST_SIZE = 0.20
N_SPLITS = 5
THRESHOLD = 0.50

BASE_DIR = Path(__file__).resolve().parent
DEFAULT_DATA = BASE_DIR / "reconstructed_caries_dataset.csv"
DEFAULT_OUT = BASE_DIR / "ml_pipeline_outputs"
TARGET_COL = "caries_outcome_12m"


def net_benefit(y_true: np.ndarray, prob: np.ndarray, pt: float) -> float:
    pred = (prob >= pt).astype(int)
    tp = ((pred == 1) & (y_true == 1)).sum()
    fp = ((pred == 1) & (y_true == 0)).sum()
    n = len(y_true)
    return (tp / n) - (fp / n) * (pt / (1 - pt))


def treat_all_net_benefit(y_true: np.ndarray, pt: float) -> float:
    n = len(y_true)
    tp = (y_true == 1).sum()
    fp = (y_true == 0).sum()
    return (tp / n) - (fp / n) * (pt / (1 - pt))


def compute_metrics(y_true: np.ndarray, prob: np.ndarray, threshold: float = 0.50) -> dict:
    pred = (prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, pred).ravel()
    return {
        "TP": int(tp),
        "FP": int(fp),
        "TN": int(tn),
        "FN": int(fn),
        "Accuracy": accuracy_score(y_true, pred),
        "Precision": precision_score(y_true, pred, zero_division=0),
        "Recall": recall_score(y_true, pred, zero_division=0),
        "F1": f1_score(y_true, pred, zero_division=0),
        "MCC": matthews_corrcoef(y_true, pred),
        "AUC": roc_auc_score(y_true, prob),
        "Brier": brier_score_loss(y_true, prob),
    }


def bootstrap_ci(y_true: np.ndarray, prob: np.ndarray, threshold: float = 0.50, n_boot: int = 1000) -> dict:
    rng = np.random.default_rng(RANDOM_STATE)
    metrics = {"Accuracy": [], "Precision": [], "Recall": [], "F1": [], "MCC": [], "AUC": []}
    n = len(y_true)

    for _ in range(n_boot):
        idx = rng.integers(0, n, n)
        yb = y_true[idx]
        pb = prob[idx]
        if len(np.unique(yb)) < 2:
            continue
        m = compute_metrics(yb, pb, threshold)
        for k in metrics:
            metrics[k].append(m[k])

    out = {}
    for k, vals in metrics.items():
        out[f"{k}_CI"] = (
            float(np.percentile(vals, 2.5)) if vals else np.nan,
            float(np.percentile(vals, 97.5)) if vals else np.nan,
        )
    return out


def build_preprocessor(X: pd.DataFrame):
    categorical_cols = [
        c for c in X.columns
        if str(X[c].dtype) == "object" or str(X[c].dtype).startswith("category")
    ]
    numeric_cols = [c for c in X.columns if c not in categorical_cols]

    numeric_transformer = Pipeline(
        steps=[
            ("imputer", KNNImputer(n_neighbors=5)),
            ("scaler", StandardScaler()),
        ]
    )

    categorical_transformer = Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ]
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ("num", numeric_transformer, numeric_cols),
            ("cat", categorical_transformer, categorical_cols),
        ]
    )
    return preprocessor


def fit_model_with_nested_rfe(
    model_name: str,
    base_estimator,
    param_grid: dict,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
):
    preprocessor = build_preprocessor(X_train)

    if model_name == "Logistic Regression":
        rfe_estimator = LogisticRegression(
            penalty="l2",
            class_weight="balanced",
            solver="liblinear",
            max_iter=2000,
            random_state=RANDOM_STATE,
        )
    elif model_name == "Random Forest":
        rfe_estimator = RandomForestClassifier(
            n_estimators=300,
            random_state=RANDOM_STATE,
            class_weight="balanced",
        )
    else:
        rfe_estimator = XGBClassifier(
            n_estimators=300,
            max_depth=5,
            learning_rate=0.05,
            subsample=0.8,
            colsample_bytree=0.8,
            eval_metric="logloss",
            random_state=RANDOM_STATE,
        )

    pipeline = Pipeline(
        steps=[
            ("preprocess", preprocessor),
            ("feature_select", RFE(estimator=rfe_estimator, n_features_to_select=8, step=1)),
            ("model", base_estimator),
        ]
    )

    cv = StratifiedKFold(n_splits=N_SPLITS, shuffle=True, random_state=RANDOM_STATE)

    search = GridSearchCV(
        estimator=pipeline,
        param_grid=param_grid,
        scoring="roc_auc",
        cv=cv,
        n_jobs=-1,
        refit=True,
    )
    search.fit(X_train, y_train)

    final_model = search.best_estimator_
    test_prob = final_model.predict_proba(X_test)[:, 1]

    selected_features = []
    try:
        pre = final_model.named_steps["preprocess"]
        feature_names = list(pre.get_feature_names_out())
        selector = final_model.named_steps["feature_select"]
        selected_features = [f for f, keep in zip(feature_names, selector.support_) if keep]
    except Exception:
        pass

    return final_model, test_prob, search.best_params_, selected_features


def shap_importance_for_xgb(model_pipeline, X_train: pd.DataFrame, X_test: pd.DataFrame, top_n: int = 10) -> pd.DataFrame:
    try:
        import shap
    except Exception:
        return pd.DataFrame({"feature": [], "mean_abs_shap": []})

    pre = model_pipeline.named_steps["preprocess"]
    sel = model_pipeline.named_steps["feature_select"]
    model = model_pipeline.named_steps["model"]

    X_test_pre = pre.transform(X_test)
    X_test_sel = sel.transform(X_test_pre)

    try:
        feature_names_all = list(pre.get_feature_names_out())
        selected_feature_names = [f for f, keep in zip(feature_names_all, sel.support_) if keep]
    except Exception:
        selected_feature_names = [f"feature_{i}" for i in range(X_test_sel.shape[1])]

    explainer = shap.TreeExplainer(model)
    shap_values = explainer.shap_values(X_test_sel)
    mean_abs = np.abs(shap_values).mean(axis=0)

    out = pd.DataFrame({
        "feature": selected_feature_names,
        "mean_abs_shap": mean_abs,
    }).sort_values("mean_abs_shap", ascending=False).head(top_n)

    return out


def main(data_path: str | Path = DEFAULT_DATA, out_dir: str | Path = DEFAULT_OUT) -> None:
    data_path = Path(data_path)
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    df = pd.read_csv(data_path)
    if TARGET_COL not in df.columns:
        raise ValueError(f"Target column '{TARGET_COL}' not found in {data_path.name}")

    y = df[TARGET_COL].astype(int)
    X = df.drop(columns=[TARGET_COL])

    X_train, X_test, y_train, y_test = train_test_split(
        X,
        y,
        test_size=TEST_SIZE,
        stratify=y,
        random_state=RANDOM_STATE,
    )

    models = {
        "Logistic Regression": {
            "estimator": LogisticRegression(
                penalty="l2",
                class_weight="balanced",
                solver="liblinear",
                max_iter=2000,
                random_state=RANDOM_STATE,
            ),
            "param_grid": {
                "model__C": [0.01, 0.1, 1, 10],
            },
        },
        "Random Forest": {
            "estimator": RandomForestClassifier(
                random_state=RANDOM_STATE,
                class_weight="balanced",
            ),
            "param_grid": {
                "model__n_estimators": [200, 500],
                "model__max_depth": [None, 6, 12, 18],
                "model__min_samples_split": [2, 5, 10],
            },
        },
        "XGBoost": {
            "estimator": XGBClassifier(
                eval_metric="logloss",
                random_state=RANDOM_STATE,
            ),
            "param_grid": {
                "model__n_estimators": [300, 500],
                "model__max_depth": [3, 5, 7],
                "model__learning_rate": [0.01, 0.05, 0.1],
                "model__subsample": [0.6, 0.8, 1.0],
                "model__colsample_bytree": [0.6, 0.8, 1.0],
                "model__reg_lambda": [0, 1, 2],
            },
        },
    }

    summary_rows = []
    ci_rows = []
    dca_rows = []
    selected_features_out = {}
    best_params_out = {}
    xgb_pipeline = None

    for model_name, cfg in models.items():
        final_model, test_prob, best_params, selected_features = fit_model_with_nested_rfe(
            model_name=model_name,
            base_estimator=cfg["estimator"],
            param_grid=cfg["param_grid"],
            X_train=X_train,
            y_train=y_train,
            X_test=X_test,
        )

        metrics = compute_metrics(y_test.to_numpy(), test_prob, THRESHOLD)
        summary_rows.append({"Model": model_name, **metrics})

        ci = bootstrap_ci(y_test.to_numpy(), test_prob, THRESHOLD, n_boot=1000)
        ci_rows.append({"Model": model_name, **ci})

        for pt in [0.10, 0.20, 0.30]:
            dca_rows.append({
                "Model": model_name,
                "Threshold": pt,
                "NetBenefit": net_benefit(y_test.to_numpy(), test_prob, pt),
                "TreatAll": treat_all_net_benefit(y_test.to_numpy(), pt),
                "TreatNone": 0.0,
            })

        best_params_out[model_name] = best_params
        selected_features_out[model_name] = selected_features

        pred_df = pd.DataFrame({
            "y_true": y_test.to_numpy(),
            "predicted_probability": test_prob,
            "predicted_class_0.50": (test_prob >= THRESHOLD).astype(int),
        })
        safe_name = model_name.lower().replace(" ", "_")
        pred_df.to_csv(out_dir / f"{safe_name}_test_predictions.csv", index=False)

        if model_name == "XGBoost":
            xgb_pipeline = final_model

    metrics_df = pd.DataFrame(summary_rows)
    ci_df = pd.DataFrame(ci_rows)
    dca_df = pd.DataFrame(dca_rows)

    metrics_df.to_csv(out_dir / "model_metrics.csv", index=False)
    ci_df.to_csv(out_dir / "bootstrap_95ci_metrics.csv", index=False)
    dca_df.to_csv(out_dir / "decision_curve_analysis.csv", index=False)

    with open(out_dir / "best_params.json", "w", encoding="utf-8") as f:
        json.dump(best_params_out, f, indent=2)

    with open(out_dir / "selected_features.json", "w", encoding="utf-8") as f:
        json.dump(selected_features_out, f, indent=2)

    if xgb_pipeline is not None:
        shap_df = shap_importance_for_xgb(xgb_pipeline, X_train, X_test, top_n=10)
        shap_df.to_csv(out_dir / "xgboost_shap_importance.csv", index=False)

    print("Finished. Outputs written to:", out_dir)
    print(metrics_df.to_string(index=False))


if __name__ == "__main__":
    main()
